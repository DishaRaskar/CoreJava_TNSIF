// Program to demonstrate on abstract keyword
package org.tnsif.abstractkeyword;

public class CheeseCornSandwich extends Sandwich {

	@Override
	void prepare() {
		System.out.println("Cheese corn Sandwich😊😊😊 ");  // win+. for emojis
	}

}
