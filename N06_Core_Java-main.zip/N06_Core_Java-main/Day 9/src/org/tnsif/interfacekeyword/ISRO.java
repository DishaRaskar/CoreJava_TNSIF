// Program to demonstrate on interface keyword
package org.tnsif.interfacekeyword;
// implementable child or child class
public class ISRO implements ChandrayaanThree {
		@Override
		public void status()
		{
			System.out.println("Chandrayaan is on Moon");
		}

}
