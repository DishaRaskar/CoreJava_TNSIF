// Program to demonstrate on functional interface 
package org.tnsif.interfacekeyword;
@FunctionalInterface
public interface ChandrayaanThree {
// Functional interface contains exactly one abstract method
	void status();
//	void displayResult();
}
