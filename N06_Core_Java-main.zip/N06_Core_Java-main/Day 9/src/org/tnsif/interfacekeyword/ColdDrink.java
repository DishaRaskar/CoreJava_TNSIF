// Program to demonstrate on interface keyword
package org.tnsif.interfacekeyword;
// Parent Interface(A)
public interface ColdDrink {
	String coldDrinkName= "Spirit";
	void showDrink();
}
