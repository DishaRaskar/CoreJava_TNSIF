// Program to demonstrate on interface keyword
package org.tnsif.interfacekeyword;
// Parent interface(B)
public interface AlcoholDrinks {
	String alcoholType= "Whiskey";
	String brand= "Imperial Blue";
	void showDrink();
}
