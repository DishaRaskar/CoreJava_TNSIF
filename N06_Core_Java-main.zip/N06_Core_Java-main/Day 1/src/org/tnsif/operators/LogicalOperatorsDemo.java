//Program to Demonstrate Logical Operators.
package org.tnsif.operators;

public class LogicalOperatorsDemo {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		System.out.println(31!=7 && 3>=7);	
		System.out.println(31!=7 || 3<=7);
		System.out.println(!(31!=7 || 3<=7));
		
	}
		

}