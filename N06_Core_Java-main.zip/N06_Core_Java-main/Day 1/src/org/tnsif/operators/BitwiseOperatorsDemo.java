// Program to demonstrate on Bitwise Operators ... &, |, ^,<<, >> 
package org.tnsif.operators;

public class BitwiseOperatorsDemo {

	public static void main(String[] args) {
		int x= 56, y= 5;
		
		System.out.println(x&y); 	
		System.out.println(x|y);
		System.out.println(x^y);
		System.out.println(8>>1);
		System.out.println(8<<1);
		
	}

}