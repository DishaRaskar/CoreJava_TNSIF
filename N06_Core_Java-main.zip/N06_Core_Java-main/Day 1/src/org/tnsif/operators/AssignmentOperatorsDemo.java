//Program to Demonstrate on Assignment Operators.
package org.tnsif.operators;

public class AssignmentOperatorsDemo {

	public static void main(String[] args) {
		int num1=12, num2=7;
		num1-=num2;  //num1=num1-num2;
		System.out.println(num1);
		

	}

}