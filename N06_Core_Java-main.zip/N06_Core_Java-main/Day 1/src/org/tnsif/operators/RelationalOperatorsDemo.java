// Program to Demonstrate the Relational Operators.
package org.tnsif.operators;

public class RelationalOperatorsDemo {

	public static void main(String[] args) {
		System.out.println(5==8);
		System.out.println(4!=3);

	}

}