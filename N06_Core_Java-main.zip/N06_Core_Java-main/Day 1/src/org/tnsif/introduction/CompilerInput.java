//Program to Demonstrate On Compiler Input.
package org.tnsif.introduction;

public class CompilerInput {

	public static void main(String[] args) 
	{
		short num=34;
		System.out.println("Num is : "+num);		

	}

}