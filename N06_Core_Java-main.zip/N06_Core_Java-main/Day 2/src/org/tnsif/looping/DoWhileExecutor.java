// Program to demonstrate Do While Loop 
package org.tnsif.looping;

public class DoWhileExecutor {

	public static void main(String[] args) {
		int x=12;
		do {
			System.out.println("The value of x is:"+x);
			x++;
		}while(x<15);
			
	}

}