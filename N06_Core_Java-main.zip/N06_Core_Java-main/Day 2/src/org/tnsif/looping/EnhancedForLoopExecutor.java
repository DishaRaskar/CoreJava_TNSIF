// Program to demonstrate Enhanced For Loop 
package org.tnsif.looping;

public class EnhancedForLoopExecutor {

	public static void main(String[] args) {
		
		char c[]= {'d','T','r'};
		for(int i:c) {
			System.out.println(i+ " ");
		}
		/*
		int arr[]= {100,84,114};
		for(char i:arr) {
			System.out.println(i+ " ");
		}
		*/
	}

}