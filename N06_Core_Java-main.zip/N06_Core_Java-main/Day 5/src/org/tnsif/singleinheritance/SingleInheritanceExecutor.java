// Program to demonstrate Single Inheritance
// driver class
package org.tnsif.singleinheritance;

public class SingleInheritanceExecutor {

		public static void main(String [] args) {
			Student s= new Student("Nagpur",440018,"Ganeshpeth",7755756747L,234,"IIM Nagpur");
			System.out.println(s);
					
		}
}
