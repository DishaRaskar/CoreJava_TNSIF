// Program to demonstrate on hierarchical inheritance
// driver class
package org.tnsif.hierarchicalinheritance;

public class HierarchicalInheritanceExecutor {

	public static void main(String[] args) {
		Tiramisu t= new Tiramisu("Realme","Double slots",13);
		SnowCone s= new SnowCone("Samsung","Double slots",12);
		
		System.out.println(t);
		System.out.println(s);

	}

}
