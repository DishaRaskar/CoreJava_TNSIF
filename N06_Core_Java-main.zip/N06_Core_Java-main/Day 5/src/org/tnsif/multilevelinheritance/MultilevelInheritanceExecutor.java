// Program to demonstrate on multilevel inheritance
// driver class
package org.tnsif.multilevelinheritance;

public class MultilevelInheritanceExecutor {

	public static void main(String[] args) {

		TeamMember t= new TeamMember("IT","Supriya",123,"Vikas","Woman security",6,15);
		System.out.println(t);
	}

}
