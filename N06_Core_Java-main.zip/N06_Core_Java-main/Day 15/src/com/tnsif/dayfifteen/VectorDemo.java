package com.tnsif.dayfifteen;

import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		Vector<Integer> v=new Vector<Integer>();
		v.add(20);
		v.add(10);
		v.add(30);
		v.add(60);
		
		System.out.println(v);

	}

}
