package org.tnsif.codingchallenge;

public class TrappingRainWater {

	public static void main(String[] args) {

		
	}

}
