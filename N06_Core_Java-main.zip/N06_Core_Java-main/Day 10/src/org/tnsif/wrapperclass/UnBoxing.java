// Program to demonstrate on UnBoxing
/* Conversion of object type to primitive
 * 
 */
package org.tnsif.wrapperclass;

public class UnBoxing {

	public static void main(String[] args) {

		Character ch= 's';
		// conversion of object type to primitive
		char c= ch;
		System.out.println(c);    // with obj type u will get class not with primitive data type
		
	}

}
